
import React, { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { generateFoundationFiles } from './services/geminiService';
import { FoundationFile } from './types';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState<'arena' | 'matches' | 'bank' | 'profile' | 'dev'>('arena');
  const [balance, setBalance] = useState(1250.00);
  const [escrow, setEscrow] = useState(0.00);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  // User Stats Mock
  const user = {
    name: "DueloPlayer_01",
    mlbbId: "98234122 (1022)",
    rank: "Mítico",
    stars: 42,
    winRate: "62.5%",
    totalMatches: 450
  };

  // State for Duelos and Files
  const [activeMatches, setActiveMatches] = useState<any[]>([]);
  const [foundationFiles, setFoundationFiles] = useState<FoundationFile[]>([]);
  const [history, setHistory] = useState([
    { id: 1, type: 'PIX_IN', amount: 500, date: '12/05/2024', status: 'CONCLUÍDO' },
    { id: 2, type: 'DUELO_WIN', amount: 36, date: '11/05/2024', status: 'CONFIRMADO' },
    { id: 3, type: 'WITHDRAW', amount: -200, date: '10/05/2024', status: 'PROCESSANDO' },
  ]);

  const challenges = [
    { id: 1, player: 'Victor_ML', rank: 'Mítico', stake: 20, reward: 36, winRate: '68%', mode: 'Solo 1v1' },
    { id: 2, player: 'Slayer_BR', rank: 'Lenda', stake: 50, reward: 90, winRate: '54%', mode: 'Solo 1v1' },
    { id: 3, player: 'MobaKing', rank: 'Mítico', stake: 100, reward: 180, winRate: '72%', mode: 'Squad 5v5' },
    { id: 4, player: 'Zoro_Roronoa', rank: 'Mítico', stake: 10, reward: 18, winRate: '50%', mode: 'Solo 1v1' },
  ];

  const handleStartCamera = async () => {
    setShowScanner(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      console.error("Camera error:", err);
      alert("Erro ao acessar câmera para OCR.");
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
    }
    setShowScanner(false);
  };

  const handleAcceptChallenge = (challenge: any) => {
    if (balance < challenge.stake) return alert("Saldo insuficiente.");
    setIsProcessing(true);
    setTimeout(() => {
      setBalance(prev => prev - challenge.stake);
      setEscrow(prev => prev + challenge.stake);
      setActiveMatches(prev => [{...challenge, status: 'Em Partida', id: Date.now()}, ...prev]);
      setIsProcessing(false);
      setActiveTab('matches');
    }, 1200);
  };

  const confirmVictory = (matchId: number) => {
    setIsProcessing(true);
    setTimeout(() => {
      const match = activeMatches.find(m => m.id === matchId);
      setEscrow(prev => prev - match.stake);
      setBalance(prev => prev + match.reward);
      setHistory(prev => [{ id: Date.now(), type: 'DUELO_WIN', amount: match.reward, date: 'Hoje', status: 'CONFIRMADO' }, ...prev]);
      setActiveMatches(prev => prev.filter(m => m.id !== matchId));
      setIsProcessing(false);
      stopCamera();
      alert("IA validou seu print! R$ " + match.reward + " creditados.");
    }, 2500);
  };

  const NavItem = ({ id, icon, label }: { id: any, icon: string, label: string }) => (
    <button 
      onClick={() => setActiveTab(id)}
      className={`flex flex-col items-center justify-center gap-1 w-full py-3 transition-all ${activeTab === id ? 'text-[#C9A050]' : 'text-slate-500'}`}
    >
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={icon} /></svg>
      <span className="text-[8px] font-black uppercase tracking-tighter">{label}</span>
    </button>
  );

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#070b14] flex flex-col items-center justify-center p-8">
        <div className="w-24 h-24 bg-[#C9A050] rounded-[2rem] flex items-center justify-center mb-8 shadow-[0_20px_50px_rgba(201,160,80,0.2)]">
          <svg className="w-12 h-12 text-black" fill="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
        </div>
        <h1 className="text-5xl font-black text-white italic tracking-tighter mb-2">DUELO<span className="text-[#C9A050]">GG</span></h1>
        <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.5em] mb-12">Mobile Legends P2P Arena</p>
        <button onClick={() => setIsLoggedIn(true)} className="w-full max-w-xs bg-[#C9A050] text-black font-black py-5 rounded-3xl uppercase tracking-widest text-xs hover:scale-105 transition-all shadow-xl shadow-[#C9A050]/20">Acessar Arena</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-200 flex flex-col pb-24 lg:pb-0 lg:pl-72">
      {/* Desktop Sidebar */}
      <aside className="fixed left-0 top-0 bottom-0 w-72 bg-[#0F1523] border-r border-white/5 hidden lg:flex flex-col p-10 z-50">
        <div className="text-3xl font-black italic mb-16">DUELO<span className="text-[#C9A050]">GG</span></div>
        <nav className="space-y-4">
          {['arena', 'matches', 'bank', 'profile'].map((tab) => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab as any)} 
              className={`w-full flex items-center gap-4 p-5 rounded-[1.5rem] transition-all uppercase text-[10px] font-black tracking-widest ${activeTab === tab ? 'bg-[#C9A050] text-black' : 'text-slate-500 hover:bg-white/5'}`}
            >
              <span className="w-5 h-5 flex items-center justify-center">
                {tab === 'arena' && '⚔️'} {tab === 'matches' && '🏆'} {tab === 'bank' && '💰'} {tab === 'profile' && '👤'}
              </span>
              {tab}
            </button>
          ))}
        </nav>
        <div className="mt-auto">
          <button onClick={() => setActiveTab('dev')} className="flex items-center gap-3 text-[9px] font-black text-slate-600 uppercase tracking-widest hover:text-blue-400 transition-all">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>
            Modo Arquiteto (Passo 1)
          </button>
        </div>
      </aside>

      {/* Main UI */}
      <main className="flex-1 p-6 lg:p-12 max-w-5xl mx-auto w-full">
        {activeTab === 'arena' && (
          <div className="space-y-8 animate-fade-in">
            <div className="flex justify-between items-end">
              <div>
                <h2 className="text-4xl font-black italic tracking-tighter">ARENA <span className="text-[#C9A050]">LOBBY</span></h2>
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-1">Duelos de Habilidade • 24/7 Ativo</p>
              </div>
              <div className="bg-[#0F1523] px-6 py-3 rounded-2xl border border-white/5 text-right shadow-xl">
                <p className="text-[9px] text-slate-500 font-black uppercase">Saldo</p>
                <p className="text-xl font-black text-[#C9A050] italic">R$ {balance.toFixed(2)}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {challenges.map(c => (
                <div key={c.id} className="bg-[#0F1523] p-8 rounded-[2.5rem] border border-white/5 hover:border-[#C9A050]/40 transition-all group relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4">
                     <span className="text-[8px] font-black bg-white/5 px-2 py-1 rounded text-slate-500 uppercase">{c.mode}</span>
                  </div>
                  <div className="flex items-center gap-5 mb-6">
                    <div className="w-14 h-14 bg-slate-900 rounded-2xl flex items-center justify-center font-black text-[#C9A050] italic border border-white/5">{c.player[0]}</div>
                    <div>
                      <h4 className="text-lg font-black italic">{c.player}</h4>
                      <p className="text-[9px] font-bold text-slate-500 uppercase">{c.rank} • WR {c.winRate}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between border-t border-white/5 pt-6">
                    <div>
                      <p className="text-[8px] text-slate-500 font-black uppercase">Prêmio</p>
                      <p className="text-2xl font-black text-[#C9A050] italic">R$ {c.reward.toFixed(2)}</p>
                    </div>
                    <button onClick={() => handleAcceptChallenge(c)} className="bg-[#C9A050] text-black font-black px-8 py-4 rounded-2xl text-[10px] uppercase tracking-widest hover:scale-105 transition-all">DESAFIAR</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'matches' && (
          <div className="space-y-6 animate-fade-in">
            <h2 className="text-3xl font-black italic uppercase">Meus <span className="text-[#C9A050]">Duelos</span></h2>
            {activeMatches.length === 0 ? (
              <div className="bg-[#0F1523] p-20 rounded-[3rem] border border-white/5 text-center">
                <p className="text-slate-500 font-black text-xs uppercase italic tracking-widest">Nenhuma batalha ativa.</p>
              </div>
            ) : (
              activeMatches.map(m => (
                <div key={m.id} className="bg-[#0F1523] p-10 rounded-[3rem] border border-white/10 space-y-8 relative overflow-hidden">
                  <div className="flex justify-between items-center relative z-10">
                    <span className="text-[10px] font-black text-emerald-500 uppercase flex items-center gap-2">
                       <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span> EM ANDAMENTO
                    </span>
                    <span className="text-[9px] text-slate-500 font-black uppercase">Escrow: R$ {m.stake}</span>
                  </div>
                  <div className="flex items-center justify-around py-4">
                     <div className="text-center"><p className="text-2xl font-black italic">{user.name}</p><p className="text-[9px] text-slate-500 font-bold uppercase">{user.rank}</p></div>
                     <div className="text-3xl font-black text-[#C9A050] italic">VS</div>
                     <div className="text-center"><p className="text-2xl font-black italic">{m.player}</p><p className="text-[9px] text-slate-500 font-bold uppercase">{m.rank}</p></div>
                  </div>
                  <button onClick={handleStartCamera} className="w-full bg-[#C9A050] text-black font-black py-5 rounded-3xl uppercase text-[10px] tracking-widest">Submeter Print da Vitória</button>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'bank' && (
          <div className="space-y-10 animate-fade-in">
            <div className="bg-[#0F1523] p-12 rounded-[3.5rem] border border-white/5 text-center shadow-2xl">
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em] mb-4">Saldo DueloBank</p>
              <h3 className="text-7xl font-black text-white italic tracking-tighter mb-10">R$ {balance.toFixed(2)}</h3>
              <div className="flex gap-4">
                <button className="flex-1 bg-[#C9A050] text-black font-black py-5 rounded-2xl text-[10px] uppercase tracking-widest">Depositar Pix</button>
                <button className="flex-1 bg-white/5 border border-white/10 py-5 rounded-2xl text-[10px] font-black uppercase tracking-widest">Sacar</button>
              </div>
            </div>
            
            <div className="space-y-4">
               <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Histórico Recente</h4>
               {history.map(h => (
                 <div key={h.id} className="bg-[#0F1523] p-6 rounded-3xl border border-white/5 flex justify-between items-center">
                    <div className="flex gap-4 items-center">
                       <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black ${h.amount > 0 ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>{h.amount > 0 ? '+' : '-'}</div>
                       <div>
                          <p className="text-xs font-black italic">{h.type === 'PIX_IN' ? 'Depósito Pix' : h.type === 'DUELO_WIN' ? 'Vitória em Duelo' : 'Saque Realizado'}</p>
                          <p className="text-[9px] text-slate-500 font-bold uppercase">{h.date} • {h.status}</p>
                       </div>
                    </div>
                    <p className={`text-sm font-black italic ${h.amount > 0 ? 'text-emerald-500' : 'text-red-500'}`}>R$ {Math.abs(h.amount).toFixed(2)}</p>
                 </div>
               ))}
            </div>
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="max-w-2xl mx-auto space-y-8 animate-fade-in">
             <div className="bg-[#0F1523] p-10 rounded-[3rem] border border-white/5 text-center">
                <div className="w-24 h-24 bg-slate-900 rounded-[2rem] border-2 border-[#C9A050] mx-auto mb-6 flex items-center justify-center text-4xl font-black italic text-[#C9A050]">{user.name[0]}</div>
                <h3 className="text-2xl font-black italic">{user.name}</h3>
                <p className="text-[10px] font-black text-[#C9A050] uppercase tracking-widest mt-1">{user.mlbbId}</p>
                <div className="grid grid-cols-3 gap-4 mt-10">
                   <div className="p-4 bg-white/5 rounded-2xl"><p className="text-[8px] text-slate-500 font-black uppercase">Win Rate</p><p className="text-lg font-black text-white italic">{user.winRate}</p></div>
                   <div className="p-4 bg-white/5 rounded-2xl"><p className="text-[8px] text-slate-500 font-black uppercase">Partidas</p><p className="text-lg font-black text-white italic">{user.totalMatches}</p></div>
                   <div className="p-4 bg-white/5 rounded-2xl"><p className="text-[8px] text-slate-500 font-black uppercase">Rank</p><p className="text-lg font-black text-white italic">{user.rank}</p></div>
                </div>
             </div>
          </div>
        )}

        {activeTab === 'dev' && (
          <div className="space-y-8 animate-fade-in">
             <div className="bg-blue-600/10 border border-blue-600/20 p-10 rounded-[3rem] text-center">
                <h3 className="text-xl font-black italic mb-4">SISTEMA DE <span className="text-blue-500">ARQUITETURA</span></h3>
                <p className="text-xs text-slate-400 font-medium max-w-md mx-auto mb-8">Aqui você gera os arquivos necessários para configurar o backend real (Stark Bank, OCR, Python) no seu IDE Antigravity.</p>
                <button 
                  onClick={async () => {
                    setIsProcessing(true);
                    const files = await generateFoundationFiles();
                    setFoundationFiles(files);
                    setIsProcessing(false);
                  }}
                  className="bg-blue-600 text-white font-black px-12 py-5 rounded-3xl text-[10px] uppercase tracking-widest shadow-xl shadow-blue-600/20"
                >
                  Gerar Arquivos Foundation
                </button>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {foundationFiles.map(f => (
                  <div key={f.name} className="bg-[#0F1523] border border-white/5 p-6 rounded-3xl group">
                    <div className="flex justify-between items-center mb-4">
                       <span className="text-[10px] font-black text-slate-400 uppercase">{f.name}</span>
                       <button onClick={() => navigator.clipboard.writeText(f.content)} className="text-[9px] font-black text-blue-400 uppercase">Copiar</button>
                    </div>
                    <div className="h-32 overflow-y-auto bg-slate-950/50 p-4 rounded-xl text-[9px] font-mono text-slate-600 whitespace-pre-wrap">{f.content}</div>
                  </div>
                ))}
             </div>
          </div>
        )}
      </main>

      {/* Mobile Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-[#0F1523]/95 backdrop-blur-md border-t border-white/5 flex lg:hidden z-50">
        <NavItem id="arena" icon="M13 10V3L4 14h7v7l9-11h-7z" label="Arena" />
        <NavItem id="matches" icon="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" label="Duelos" />
        <NavItem id="bank" icon="M12 8c-1.657 0-3 .895-3 2" label="Banco" />
        <NavItem id="profile" icon="M16 7a4 4 0 11-8 0" label="Perfil" />
      </nav>

      {/* Scanner Modal */}
      {showScanner && (
        <div className="fixed inset-0 z-[1000] bg-slate-950 flex flex-col items-center justify-center p-6">
           <div className="relative w-full max-w-sm aspect-[9/16] bg-black rounded-[3rem] overflow-hidden border-2 border-[#C9A050]">
              <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover grayscale opacity-50" />
              <div className="absolute inset-0 border-[40px] border-black/40"></div>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-32 border-2 border-[#C9A050] rounded-xl flex items-center justify-center">
                 <div className="w-full h-1 bg-[#C9A050] animate-scan-line"></div>
              </div>
              <div className="absolute bottom-10 left-0 right-0 text-center">
                 <p className="text-[10px] font-black text-[#C9A050] uppercase tracking-widest">Enquadre o print da Vitória</p>
              </div>
           </div>
           <div className="flex gap-4 mt-10 w-full max-w-sm">
              <button onClick={stopCamera} className="flex-1 bg-white/5 border border-white/10 py-5 rounded-2xl text-[10px] font-black uppercase">Cancelar</button>
              <button onClick={() => confirmVictory(activeMatches[0].id)} className="flex-1 bg-[#C9A050] text-black font-black py-5 rounded-2xl text-[10px] uppercase">Escanear Agora</button>
           </div>
        </div>
      )}

      {/* Global Processing Loader */}
      {isProcessing && (
        <div className="fixed inset-0 z-[2000] bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center space-y-4">
          <div className="w-16 h-16 border-8 border-[#C9A050] border-t-transparent rounded-full animate-spin"></div>
          <p className="text-[10px] font-black text-[#C9A050] uppercase tracking-[0.6em] animate-pulse">Sincronizando Servidores...</p>
        </div>
      )}

      <style>{`
        @keyframes fade-in { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade-in { animation: fade-in 0.6s cubic-bezier(0.23, 1, 0.32, 1); }
        @keyframes scan-line { 0% { transform: translateY(-60px); opacity: 0; } 50% { opacity: 1; } 100% { transform: translateY(60px); opacity: 0; } }
        .animate-scan-line { animation: scan-line 2s infinite ease-in-out; }
      `}</style>
    </div>
  );
};

export default App;
