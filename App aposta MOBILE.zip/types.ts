
export interface FoundationFile {
  name: string;
  path: string;
  content: string;
  description: string;
}

export interface MasterPlanPhase {
  id: string;
  title: string;
  tasks: MasterPlanTask[];
  status: 'pending' | 'in_progress' | 'completed';
}

export interface MasterPlanTask {
  id: string;
  description: string;
  completed: boolean;
  codeSnippet?: string;
}

export enum GenerationStatus {
  IDLE = 'IDLE',
  GENERATING = 'GENERATING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}
