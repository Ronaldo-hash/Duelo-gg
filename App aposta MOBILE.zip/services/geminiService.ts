
import { GoogleGenAI, Type } from "@google/genai";
import { FoundationFile } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateFoundationFiles = async (): Promise<FoundationFile[]> => {
  const prompt = `
    VOCÊ É O CTO E ARQUITETO SÊNIOR DO DUELOGG.
    Gere os 4 arquivos de fundação detalhados para o IDE Antigravity baseados nas seguintes restrições:
    1. PROJECT_BLUEPRINT.md: Arquitetura Monorepo (/app e /backend), fluxos de dados do Pix In ao Pix Out.
    2. LEGAL_COMPLIANCE.md: Regras rígidas contra mecânicas de RNG, Split Payment e Lei 14.790/2023.
    3. TECH_SPEC.md: Dependências para pubspec.yaml e requirements.txt (Stark Bank, OCR, FastAPI).
    4. ANTGRAVITY_MASTER_PLAN.md: Checklist de 5 fases (Config, Auth, StarkBank, OCR, Lançamento).

    Formato: Retorne um array JSON de objetos {"name", "path", "description", "content"}.
    Use o Azul Meia-Noite (#0F1523) e Dourado (#C9A050) como referências visuais no texto.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            path: { type: Type.STRING },
            description: { type: Type.STRING },
            content: { type: Type.STRING },
          },
          required: ["name", "path", "description", "content"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || "[]") as FoundationFile[];
  } catch (error) {
    console.error("Parse failed", error);
    throw new Error("Falha no Arquiteto Gemini.");
  }
};

export const generateTaskCode = async (taskDescription: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Como CTO do DueloGG, gere o código boilerplate (Python/FastAPI ou Flutter/Dart) para a seguinte tarefa do Master Plan: "${taskDescription}". Considere a stack: FastAPI, PostgreSQL, Stark Bank, ML Kit OCR.`,
  });
  return response.text || "Erro ao gerar código.";
};
